import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../widgets/status_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<FirebaseService>();
    final dateFmt = DateFormat('MMM d, yyyy • HH:mm:ss');

    return Scaffold(
      appBar: AppBar(
        title: const Text('FireGuard AI'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  svc.connected ? Icons.cloud_done : Icons.cloud_off,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(svc.connected ? 'Connected to Firebase' : 'Disconnected'),
                const Spacer(),
                Text(
                  svc.lastUpdated != null
                      ? 'Updated: ' + dateFmt.format(svc.lastUpdated!)
                      : 'Awaiting data...',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 16),
            StatusCard(
              title: 'Fire Status',
              value: svc.fireDetected ? 'FIRE DETECTED' : 'Safe',
              highlight: svc.fireDetected,
            ),
            const SizedBox(height: 12),
            StatusCard(
              title: 'MQ-2 (Smoke/Gas)',
              value: svc.mq2?.toStringAsFixed(2) ?? '--',
            ),
            const SizedBox(height: 12),
            StatusCard(
              title: 'Temperature (°C)',
              value: svc.temperature?.toStringAsFixed(1) ?? '--',
            ),
            const SizedBox(height: 12),
            StatusCard(
              title: 'Humidity (%)',
              value: svc.humidity?.toStringAsFixed(1) ?? '--',
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () {
                // Placeholder for future: acknowledge alert, manual buzzer control, etc.
              },
              icon: const Icon(Icons.notifications_active),
              label: const Text('Enable/Check Notifications'),
            ),
          ],
        ),
      ),
    );
  }
}
