import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:firebase_database/firebase_database.dart';

class FirebaseService extends ChangeNotifier {
  final _db = FirebaseDatabase.instance.ref();
  StreamSubscription<DatabaseEvent>? _sub;
  bool connected = false;

  // Live values
  double? mq2;
  double? temperature;
  double? humidity;
  bool fireDetected = false;
  DateTime? lastUpdated;

  Future<void> init() async {
    try {
      // Listen to a specific path, update this to match your ESP32 uploads
      // Example structure:
      // /fireguard/status: { fireDetected: true/false, updatedAt: 1699999999 }
      // /fireguard/sensors: { mq2: 123.4, temperature: 28.5, humidity: 65.0 }
      _sub = _db.child('fireguard').onValue.listen((event) {
        final data = event.snapshot.value as Map?;
        if (data != null) {
          final sensors = data['sensors'] as Map?;
          final status = data['status'] as Map?;
          mq2 = (sensors?['mq2'] as num?)?.toDouble();
          temperature = (sensors?['temperature'] as num?)?.toDouble();
          humidity = (sensors?['humidity'] as num?)?.toDouble();
          fireDetected = (status?['fireDetected'] as bool?) ?? false;
          final ts = (status?['updatedAt'] as num?)?.toInt();
          if (ts != null) {
            lastUpdated = DateTime.fromMillisecondsSinceEpoch(ts * 1000);
          } else {
            lastUpdated = DateTime.now();
          }
          connected = true;
        } else {
          connected = false;
        }
        notifyListeners();
      }, onError: (e) {
        connected = false;
        notifyListeners();
      });
    } catch (e) {
      connected = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
